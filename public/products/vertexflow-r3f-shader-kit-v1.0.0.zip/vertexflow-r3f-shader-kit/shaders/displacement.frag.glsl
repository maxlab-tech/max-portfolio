// VertexFlow 3D - Fragment Shader
// Supports PBR Metallic, Analytical Normal RGB Inspection, and Iridescent Rim

uniform float uTime;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform int uRenderMode;

varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;
varying vec3 vDisplacedPosition;
varying vec3 vViewPosition;

void main() {
  vec3 N = normalize(vNormal);
  vec3 V = normalize(vViewPosition);

  // Directional Key Light
  vec3 L = normalize(vec3(1.2, 1.5, 1.0));
  float NdotL = max(dot(N, L), 0.0);

  // Blinn-Phong Specular
  vec3 H = normalize(L + V);
  float NdotH = max(dot(N, H), 0.0);
  float specular = pow(NdotH, 64.0) * 1.5;

  // Fresnel grazing rim
  float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.0);

  if (uRenderMode == 1) {
    // Mode 1: Normal Vector RGB Inspection
    vec3 normalColor = N * 0.5 + 0.5;
    gl_FragColor = vec4(normalColor, 1.0);
    return;
  }

  if (uRenderMode == 2) {
    // Mode 2: Spectral Iridescent Rim
    vec3 iridescent = 0.5 + 0.5 * cos(uTime * 1.5 + N.xyx * 3.0 + vec3(0.0, 2.0, 4.0));
    vec3 finalColor = mix(vec3(0.02, 0.02, 0.05), iridescent, fresnel * 1.2 + specular * 0.6);
    gl_FragColor = vec4(finalColor, 0.95);
    return;
  }

  // Mode 0: Default Metallic PBR Lighting
  vec3 baseColor = mix(uColorA, uColorB, (vDisplacedPosition.y + 1.2) * 0.4);
  vec3 ambient = baseColor * 0.25;
  vec3 diffuse = baseColor * NdotL * 0.85;
  vec3 specColor = vec3(1.0) * specular;
  vec3 rimColor = vec3(0.0, 0.83, 0.66) * fresnel * 1.8;

  vec3 finalColor = ambient + diffuse + specColor + rimColor;
  gl_FragColor = vec4(finalColor, 1.0);
}
