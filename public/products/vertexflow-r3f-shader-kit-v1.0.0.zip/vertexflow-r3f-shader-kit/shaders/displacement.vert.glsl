// VertexFlow 3D - Vertex Shader with Analytical Normal Recalculation
// Compatible with Three.js WebGL2 & WebGL1

uniform float uTime;
uniform float uNoiseFreq;
uniform float uNoiseAmp;
uniform vec2 uPointer;
uniform float uPointerRadius;
uniform float uPointerStrength;

varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vPosition;
varying vec3 vDisplacedPosition;
varying vec3 vViewPosition;

// Simplex 3D Noise helper functions
vec4 permute(vec4 x) { return mod(((x*34.0)+1.0)*x, 289.0); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v) {
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);

  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);

  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);

  vec3 x1 = x0 - i1 + 1.0 * C.xxx;
  vec3 x2 = x0 - i2 + 2.0 * C.xxx;
  vec3 x3 = x0 - 1.0 + 3.0 * C.xxx;

  i = mod(i, 289.0);
  vec4 p = permute(permute(permute(
            i.z + vec4(0.0, i1.z, i2.z, 1.0))
          + i.y + vec4(0.0, i1.y, i2.y, 1.0))
          + i.x + vec4(0.0, i1.x, i2.x, 1.0));

  float n_ = 0.142857142857;
  vec3  ns = n_ * D.wyz - D.xzx;

  vec4 j = p - 49.0 * floor(p * ns.z *ns.z);

  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);

  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);

  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);

  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));

  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;

  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);

  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
  p0 *= norm.x;
  p1 *= norm.y;
  p2 *= norm.z;
  p3 *= norm.w;

  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}

// Procedural displacement height function
float getDisplacement(vec3 pos) {
  float primary = snoise(pos * uNoiseFreq + vec3(0.0, uTime * 0.45, 0.0));
  float octave  = snoise(pos * (uNoiseFreq * 2.1) - vec3(uTime * 0.35, 0.0, uTime * 0.2)) * 0.45;
  float d = (primary + octave) * uNoiseAmp;

  // Elastic mouse ripple
  float mouseDist = length(pos.xy - uPointer);
  float ripple = sin(mouseDist * 14.0 - uTime * 4.0) * exp(-mouseDist * 2.8) * uPointerStrength;
  return d + ripple;
}

// Generate orthogonal tangent
vec3 getOrthogonal(vec3 n) {
  return abs(n.y) < 0.99 ? normalize(cross(n, vec3(0.0, 1.0, 0.0))) : normalize(cross(n, vec3(1.0, 0.0, 0.0)));
}

void main() {
  vUv = uv;
  vec3 originalPos = position;
  vec3 baseNormal = normalize(normal);

  // Finite differences for analytical normal recalculation
  float eps = 0.005;
  vec3 tangent = getOrthogonal(baseNormal);
  vec3 bitangent = normalize(cross(baseNormal, tangent));

  vec3 pos0 = originalPos + baseNormal * getDisplacement(originalPos);
  vec3 posT = (originalPos + tangent * eps) + baseNormal * getDisplacement(originalPos + tangent * eps);
  vec3 posB = (originalPos + bitangent * eps) + baseNormal * getDisplacement(originalPos + bitangent * eps);

  vec3 vT = posT - pos0;
  vec3 vB = posB - pos0;
  vec3 calculatedNormal = normalize(cross(vT, vB));

  vNormal = normalize(normalMatrix * calculatedNormal);
  vPosition = originalPos;
  vDisplacedPosition = pos0;

  vec4 mvPosition = modelViewMatrix * vec4(pos0, 1.0);
  vViewPosition = -mvPosition.xyz;
  gl_Position = projectionMatrix * mvPosition;
}
