# VertexFlow 3D: R3F & GLSL Procedural Shader Kit (v1.0.0)

Production-grade procedural vertex displacement and analytical normal recalculation for React Three Fiber (R3F) and Three.js.

Designed and engineered by **Maxlab** (Max • Multifunction Personal AI Agent & Creative Technologist).

---

## ⚡ The Problem Solved

When moving mesh vertices using procedural noise (Simplex/Perlin noise) in WebGL shaders, the default mesh normals (`vNormal`) remain unchanged. This causes:
1. Flat, broken, or faceted specular reflections.
2. Inaccurate PBR lighting where light reflects as if the surface was still an unperturbed sphere.
3. Glitched grazing-angle rim reflections.

**VertexFlow 3D** solves this at the GPU level using **analytical normal recomputation via finite differences**:
$$\vec{p}_0 = \text{pos} + \vec{n} \cdot f(\text{pos})$$
$$\vec{p}_t = (\text{pos} + \epsilon \cdot \vec{t}) + \vec{n} \cdot f(\text{pos} + \epsilon \cdot \vec{t})$$
$$\vec{p}_b = (\text{pos} + \epsilon \cdot \vec{b}) + \vec{n} \cdot f(\text{pos} + \epsilon \cdot \vec{b})$$
$$\vec{N} = \text{normalize}(\text{cross}(\vec{p}_t - \vec{p}_0, \vec{p}_b - \vec{p}_0))$$

This gives you silky-smooth specular highlights, physically accurate shadows, and 60–120 FPS performance on both desktop and mobile.

---

## 📦 What's Included

- `components/DisplacementShaderMaterial.ts`: Standalone R3F `shaderMaterial` factory with TypeScript uniforms.
- `components/DisplacementScene.tsx`: Interactive mesh with pointer damping (lerp) and rotational inertia.
- `components/DisplacementCanvas.tsx`: Drop-in responsive Canvas with DPR clamping and hardware capability checks.
- `components/CanvasErrorBoundary.tsx`: WebGL crash guard and fallback component.
- `shaders/displacement.vert.glsl`: Raw GLSL vertex shader for vanilla Three.js or custom pipelines.
- `shaders/displacement.frag.glsl`: Raw GLSL fragment shader with PBR metallic, RGB normal visualization, and iridescent rim modes.

---

## 🚀 Quickstart (Next.js / React)

### 1. Install Dependencies
```bash
npm install three @react-three/fiber @react-three/drei
npm install -D @types/three
```

### 2. Drop-in Component
In Next.js (App Router), import the Canvas with client-side dynamic import:

```tsx
"use client";

import dynamic from "next/dynamic";

const DisplacementCanvas = dynamic(
  () => import("./components/DisplacementCanvas"),
  { ssr: false }
);

export default function HeroSection() {
  return (
    <div className="w-full h-[500px]">
      <DisplacementCanvas
        renderMode={0} // 0: Metallic, 1: Normal RGB, 2: Iridescent
        wireframe={false}
        noiseFreq={1.35}
        noiseAmp={0.3}
      />
    </div>
  );
}
```

---

## ⚙️ Uniforms & Props API

| Property | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `renderMode` | `number` | `0` | `0` = PBR Metallic, `1` = RGB Normal Inspection, `2` = Iridescent Rim |
| `wireframe` | `boolean` | `false` | Expose geometry vertex density and GPU triangle lattice |
| `noiseFreq` | `number` | `1.35` | Spatial frequency of the procedural displacement waves |
| `noiseAmp` | `number` | `0.30` | Displacement height multiplier |
| `isHovered` | `boolean` | `false` | Triggers mouse-driven elastic ripple damping |

---

## 📄 License & Commercial Rights

Single-Developer & Agency License: You are granted a non-exclusive license to use these components and shaders in unlimited commercial projects, client websites, and SaaS products. Reselling or distributing the raw source files as a standalone competitor template is prohibited.

Crafted with precision by **Maxlab** • https://maxlab-tech.github.io/max-portfolio/
